import { Component, Input } from '@angular/core';
import { trigger, transition, state, animate, style, AnimationEvent } from '@angular/animations';

@Component({
  selector: 'app-open-close',
  animations: [
    trigger('openClose', [
      // ...
      state('open', style({
        height: '200px',
        opacity: 1,
        backgroundColor: 'yellow'
      })),
      state('closed', style({
        height: '100px',
        opacity: 0.5,
        backgroundColor: 'green'
      })),
      transition('open => closed', [
        animate('1s')
      ]),
      transition('closed => open', [
        animate('0.5s')
      ]),
      transition('* => closed', [
        animate('1s')
      ]),
      transition('* => open', [
        animate('0.5s')
      ]),
      transition('open <=> closed', [
        animate('0.5s')
      ]),
      transition ('* => open', [
        animate ('1s',
          style ({ opacity: '*' }),
        ),
      ]),
      transition('* => *', [
        animate('1s')
      ]),
    ]),
  ],
  templateUrl: 'open-close.component.html',
  styleUrls: ['open-close.component.css']
})
export class OpenCloseComponent {
  isOpen = true;

  toggle() {
    this.isOpen = !this.isOpen;
  }

  @Input() logging = false;
  onAnimationEvent ( event: AnimationEvent ) {
    if (!this.logging) {
      return;
    }
    // 이 예제에서 트리거 이름은 openClose입니다.
    console.warn(`Animation Trigger: ${event.triggerName}`);

    // phaseName은 start나 done 문자열입니다.
    console.warn(`Phase: ${event.phaseName}`);

    // 이 예제에서 totalTime은 1초이거나 0.5초입니다.
    console.warn(`Total time: ${event.totalTime}`);

    // 이 예제에서 fromState는 open이거나 closed입니다.
    console.warn(`From: ${event.fromState}`);

    // 이 예제에서 toState는 open이거나 closed입니다.
    console.warn(`To: ${event.toState}`);

    // 이 예제에서 이벤트가 발생한 HTML 엘리먼트는 버튼입니다.
    console.warn(`Element: ${event.element}`);
  }
}
