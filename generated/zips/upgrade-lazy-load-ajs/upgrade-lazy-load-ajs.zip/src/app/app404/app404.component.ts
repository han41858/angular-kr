import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-app404',
  templateUrl: './app404.component.html',
  styleUrls: ['./app404.component.css']
})
export class App404Component implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
