import { browser, element, by } from 'protractor';

describe('Forms Overview Tests', () => {

  beforeEach(() => {
    browser.get('');
  });

});

