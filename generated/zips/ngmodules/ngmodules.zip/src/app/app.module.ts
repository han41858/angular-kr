
import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

/* 애플리케이션 최상위 컴포넌트 */
import { AppComponent } from './app.component';

/* 기능 모듈 */
import { ContactModule } from './contact/contact.module';
import { GreetingModule } from './greeting/greeting.module';

/* 라우팅 모듈 */
import { AppRoutingModule } from './app-routing.module';

@NgModule({
  imports: [
    BrowserModule,
    ContactModule,
    GreetingModule.forRoot({userName: 'Miss Marple'}),
    AppRoutingModule
  ],
  declarations: [
    AppComponent
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
