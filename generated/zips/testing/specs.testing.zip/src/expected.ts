/* Ignore. Satisfies static analysis of router config in app.component.router.spec.ts */
