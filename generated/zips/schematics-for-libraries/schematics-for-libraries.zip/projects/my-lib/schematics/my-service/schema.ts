export interface Schema {
  // 서비스 이름
  name: string;

  // 서비스 생성 위치
  path?: string;

  // 프로젝트 이름
  project?: string;
}
