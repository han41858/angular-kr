import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
// 새로 만든 컴포넌트를 로드합니다.
import { CustomerDashboardComponent } from './customer-dashboard/customer-dashboard.component';


@NgModule({
  imports: [
    CommonModule
  ],
  declarations: [
    CustomerDashboardComponent
  ],
  exports: [
    CustomerDashboardComponent
  ]
})


export class CustomerDashboardModule { }

